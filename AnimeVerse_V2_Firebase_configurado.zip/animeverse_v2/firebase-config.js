// Configuração da aplicação Web Firebase - AnimeVerse V2
export const firebaseConfig = {
  apiKey: "AIzaSyCOVIpY2VDkIxTP-82_I5ZhG-uYzronQlk",
  authDomain: "animeverse-v2.firebaseapp.com",
  projectId: "animeverse-v2",
  storageBucket: "animeverse-v2.firebasestorage.app",
  messagingSenderId: "252261763743",
  appId: "1:252261763743:web:87c84a581073c4237930aa"
};
