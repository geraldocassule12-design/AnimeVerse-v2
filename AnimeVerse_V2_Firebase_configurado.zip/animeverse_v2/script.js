import { initializeApp } from "https://www.gstatic.com/firebasejs/11.0.2/firebase-app.js";
import {
  getAuth, onAuthStateChanged, createUserWithEmailAndPassword,
  signInWithEmailAndPassword, GoogleAuthProvider, signInWithPopup, signOut,
  updateProfile
} from "https://www.gstatic.com/firebasejs/11.0.2/firebase-auth.js";
import {
  getFirestore, doc, setDoc, getDoc, collection, getDocs, addDoc, deleteDoc,
  serverTimestamp, query, orderBy
} from "https://www.gstatic.com/firebasejs/11.0.2/firebase-firestore.js";
import { firebaseConfig } from "./firebase-config.js";

const chapters=[
{title:"A Marca",text:["A cidade de Nambara acordava lentamente. Malik atravessava a rua com os auscultadores nos ouvidos, tentando ignorar o céu estranho que cobria os edifícios.","Naquela noite, completavam-se quinze anos desde a Chuva de Luz. Toda a gente conhecia as histórias sobre as Sombras, mas Malik achava que eram apenas lendas.","Quando chegou a casa, encontrou a porta entreaberta. No corredor, uma pequena luz azul pulsava no chão. Ao aproximar a mão, uma marca surgiu na sua palma.","— Finalmente… — sussurrou uma voz que parecia vir de dentro da própria luz.","Malik recuou. Do lado de fora, todas as luzes da rua apagaram-se ao mesmo tempo. Uma silhueta alta apareceu no fim do corredor.","A marca brilhou. E, pela primeira vez, Malik ouviu o mundo prender a respiração."]},
{title:"A Voz na Escuridão",text:["A silhueta não se mexia. Malik sentia o coração acelerar, mas a marca na sua mão mantinha-se quente, como se tentasse avisá-lo.","— Não tenhas medo de mim — disse a voz. — O perigo está atrás de ti.","Uma sombra atravessou a parede. Malik fechou os olhos e ergueu o braço. Um círculo azul surgiu no ar, iluminando o corredor.","Quando a luz desapareceu, a criatura tinha recuado. No chão ficou apenas uma pena negra.","A sua irmã mais velha, Lina, apareceu à porta. Ao ver a marca, deixou cair as chaves.","— Malik… onde encontraste isso? — perguntou ela. — O nosso pai tinha a mesma marca."]},
{title:"O Primeiro Despertar",text:["Lina levou Malik até ao velho observatório no alto da cidade. Lá dentro, mapas antigos cobriam as paredes e um símbolo igual ao da sua mão estava gravado numa mesa.","— O pai fazia parte dos Guardiões do Véu — explicou Lina. — Eles protegiam a cidade das Sombras.","Um estrondo fez o observatório tremer. Do lado de fora, uma nuvem escura cobriu a lua.","Malik sentiu a marca aquecer. Desta vez, não tentou esconder a mão. Respirou fundo e deixou a luz crescer.","Um arco luminoso abriu-se à sua frente. A sombra que entrou no observatório recuou, revelando dois olhos prateados.","Lina sorriu, apesar do medo. — O teu despertar começou. Mas esta é apenas a primeira noite."]}
];
const defaults=[
{id:"ashes",title:"As Cinzas do Amanhã",category:"Ação",genre:"AÇÃO · FANTASIA",description:"Um jovem descobre um poder que devia permanecer escondido.",cover:"ashes",chapters:chapters.map(c=>({title:c.title,text:c.text.join("\n\n")})),original:true},
{id:"clock",title:"O Último Minuto",category:"Mistério",genre:"MISTÉRIO · FANTASIA",description:"Uma cidade onde todos os relógios param à meia-noite.",cover:"clock",soon:true},
{id:"sky",title:"Além do Horizonte",category:"Aventura",genre:"AVENTURA",description:"Uma equipa procura uma ilha que não existe nos mapas.",cover:"sky",soon:true},
{id:"rose",title:"A Canção das Estrelas",category:"Fantasia",genre:"FANTASIA",description:"Uma aprendiz descobre que a sua voz pode mudar o destino.",cover:"rose",soon:true}
];
let app,auth,db,currentUser=null,isAdmin=false,comics=[...defaults],activeChapter=0,activeComic=null,accountMode="login";
const $=id=>document.getElementById(id);
function esc(s){return String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
function info(title,msg){$("infoTitle").textContent=title;$("infoText").textContent=msg;showModal("infoModal")}
function showModal(id){$(id).classList.remove("hidden");document.body.style.overflow="hidden"}
function closeModal(id){$(id).classList.add("hidden");if(!document.querySelector(".modal:not(.hidden)"))document.body.style.overflow=""}
document.querySelectorAll("[data-close]").forEach(b=>b.addEventListener("click",()=>closeModal(b.dataset.close)));
document.querySelectorAll(".modal").forEach(m=>m.addEventListener("click",e=>{if(e.target===m)closeModal(m.id)}));
document.addEventListener("keydown",e=>{if(e.key==="Escape")document.querySelectorAll(".modal:not(.hidden)").forEach(m=>closeModal(m.id))});
function renderCatalog(filter="Todos"){
 const grid=$("comicGrid"),shown=comics.filter(c=>filter==="Todos"||c.category===filter);
 grid.innerHTML=shown.map(c=>`<article class="comic-card"><div class="cover cover-${esc(c.cover||"ashes")}"><span class="cover-tag">${c.original?"ORIGINAL":c.soon?"EM BREVE":"NOVO"}</span><div class="cover-title">${esc(c.title.toUpperCase())}</div><small>ANIMEVERSE STORIES</small></div><div class="comic-info"><span class="genre">${esc(c.genre||c.category.toUpperCase())}</span><h3>${esc(c.title)}</h3><p>${esc(c.description)}</p><button class="read-btn" data-read="${esc(c.id)}">${c.soon?"Em breve":"Ler história"} <span>→</span></button></div></article>`).join("");
 $("comicCount").textContent=comics.length;
 grid.querySelectorAll("[data-read]").forEach(b=>b.addEventListener("click",()=>{const c=comics.find(x=>x.id===b.dataset.read);if(c?.soon){info("Em preparação","Esta história ainda está a ser preparada.");return}openComic(c,0)}));
}
function renderChapters(){const c=comics.find(x=>x.id==="ashes");$("chapterList").innerHTML=(c?.chapters||[]).map((ch,i)=>`<button class="chapter" data-chapter="${i}"><span>${String(i+1).padStart(2,"0")}</span><span class="chapter-info"><b>${esc(ch.title)}</b><small>Capítulo ${i+1}</small></span><span class="chapter-arrow">→</span></button>`).join("");document.querySelectorAll("[data-chapter]").forEach(b=>b.addEventListener("click",()=>openComic(c,Number(b.dataset.chapter))))}
function openComic(comic,index){if(!comic||!comic.chapters?.length){info("Sem capítulos","Ainda não há capítulos publicados.");return}activeComic=comic;activeChapter=Math.max(0,Math.min(index,comic.chapters.length-1));const ch=comic.chapters[activeChapter];$("readerTitle").textContent=ch.title;$("chapterCounter").textContent=`${comic.title} · CAPÍTULO ${String(activeChapter+1).padStart(2,"0")}`;$("readerText").innerHTML=ch.text.split(/\n+/).map(p=>`<p>${esc(p)}</p>`).join("");$("prevChapter").disabled=activeChapter===0;$("nextChapter").textContent=activeChapter===comic.chapters.length-1?"Fechar":"Próximo →";showModal("readerModal")}
$("startReading").addEventListener("click",()=>openComic(comics.find(c=>c.id==="ashes"),0));
$("prevChapter").addEventListener("click",()=>openComic(activeComic,activeChapter-1));
$("nextChapter").addEventListener("click",()=>activeChapter===activeComic.chapters.length-1?closeModal("readerModal"):openComic(activeComic,activeChapter+1));
document.querySelectorAll(".filter").forEach(b=>b.addEventListener("click",()=>{document.querySelectorAll(".filter").forEach(x=>x.classList.remove("active"));b.classList.add("active");renderCatalog(b.dataset.filter)}));
$("menuToggle").addEventListener("click",()=>$("nav").classList.toggle("open"));

function accountTab(){document.querySelectorAll(".tab").forEach(t=>t.classList.toggle("active",t.dataset.tab===accountMode));$("accountTitle").textContent=accountMode==="login"?"Entrar":"Criar conta";$("accountSubmit").textContent=accountMode==="login"?"Entrar":"Criar conta";$("registerFields").classList.toggle("hidden",accountMode!=="register");$("nameLabel").classList.toggle("hidden",accountMode!=="register");$("accountName").required=accountMode==="register";$("accountAge").required=accountMode==="register";$("accountMessage").textContent=""}
document.querySelectorAll(".tab").forEach(t=>t.addEventListener("click",()=>{accountMode=t.dataset.tab;accountTab()}));
function showAccount(){accountMode="login";accountTab();showModal("accountModal")}
async function saveProfile(user,age=null,guardianConsent=false){
 const ref=doc(db,"users",user.uid),old=await getDoc(ref);
 const profile={uid:user.uid,email:user.email||"",displayName:user.displayName||user.email||"Utilizador",updatedAt:serverTimestamp()};
 if(!old.exists()){
   if(age===null) return;
   profile.age=age;profile.guardianConsent=!!guardianConsent;profile.createdAt=serverTimestamp();
   await setDoc(ref,profile);
 }else{
   await setDoc(ref,profile,{merge:true});
 }
}
async function updateAccountUI(user){currentUser=user;isAdmin=false;if(user){try{const token=await user.getIdTokenResult(true);isAdmin=token.claims.admin===true}catch(e){console.warn(e)}try{await saveProfile(user)}catch(e){console.warn("Perfil não sincronizado",e)}}$("userGreeting").textContent=user?`Olá, ${(user.displayName||user.email||"").split("@")[0]}`:"";$("accountBtn").textContent=user?"Sair":"Entrar";$("adminNav").classList.toggle("hidden",!isAdmin);if(isAdmin) $("adminNav").style.display="inline";await loadComics();if(isAdmin)renderAdminList()}
$("accountBtn").addEventListener("click",async()=>{if(currentUser){await signOut(auth);info("Sessão terminada","Saíste da tua conta AnimeVerse.")}else showAccount()});
$("accountForm").addEventListener("submit",async e=>{e.preventDefault();const email=$("accountEmail").value.trim(),pass=$("accountPassword").value,msg=$("accountMessage");msg.textContent="A processar…";try{if(accountMode==="register"){const age=Number($("accountAge").value),consent=$("guardianConsent").checked;if(!Number.isInteger(age)||age<8||age>120){msg.textContent="A idade mínima é 8 anos.";return}if(age<13&&!consent){msg.textContent="É necessária autorização do responsável para continuar.";return}const cred=await createUserWithEmailAndPassword(auth,email,pass);const name=$("accountName").value.trim();if(name)await updateProfile(cred.user,{displayName:name});await saveProfile(cred.user,age,consent);closeModal("accountModal")}else{await signInWithEmailAndPassword(auth,email,pass);closeModal("accountModal")}}catch(err){msg.textContent=friendlyError(err)}});
$("googleBtn").addEventListener("click",async()=>{try{const cred=await signInWithPopup(auth,new GoogleAuthProvider());const snap=await getDoc(doc(db,"users",cred.user.uid));if(!snap.exists()||!snap.data().age){const age=Number(prompt("Para concluir o registo, indica a idade do utilizador (mínimo 8 anos):"));if(!Number.isInteger(age)||age<8||age>120){await signOut(auth);info("Registo não concluído","É necessário ter pelo menos 8 anos e indicar a idade.");return}let consent=false;if(age<13){consent=confirm("O teu pai/mãe ou responsável autorizou a utilização?");if(!consent){await signOut(auth);return}}await saveProfile(cred.user,age,consent)}closeModal("accountModal")}catch(e){$("accountMessage").textContent=friendlyError(e)}});
function friendlyError(e){const code=e?.code||"";return ({ "auth/email-already-in-use":"Este e-mail já tem uma conta.","auth/invalid-email":"E-mail inválido.","auth/weak-password":"A palavra-passe deve ter pelo menos 6 caracteres.","auth/invalid-credential":"E-mail ou palavra-passe incorretos.","auth/popup-closed-by-user":"A janela Google foi fechada.","auth/unauthorized-domain":"Este domínio ainda não está autorizado no Firebase."})[code]||e.message||"Ocorreu um erro."}

async function loadComics(){if(!db)return;try{const snap=await getDocs(query(collection(db,"comics"),orderBy("createdAt","desc")));if(!snap.empty){comics=snap.docs.map(d=>({id:d.id,...d.data()}));renderCatalog(document.querySelector(".filter.active")?.dataset.filter||"Todos");renderChapters()}}catch(e){console.warn("A usar catálogo incorporado",e)}}
function renderAdminList(){const el=$("adminComicList");if(!isAdmin){el.innerHTML="<p class='fineprint'>Acesso não autorizado.</p>";return}el.innerHTML=comics.map(c=>`<div class="admin-item"><span>${esc(c.title)}</span><button data-delete="${esc(c.id)}">Apagar</button></div>`).join("");el.querySelectorAll("[data-delete]").forEach(b=>b.addEventListener("click",async()=>{if(!isAdmin)return;try{await deleteDoc(doc(db,"comics",b.dataset.delete));comics=comics.filter(c=>c.id!==b.dataset.delete);renderCatalog();renderAdminList()}catch(e){info("Erro ao apagar",friendlyError(e))}}))}
function openAdmin(){if(!currentUser||!isAdmin){info("Acesso restrito","Esta conta não tem permissões de administrador.");return}renderAdminList();showModal("adminModal")}
$("adminNav").addEventListener("click",e=>{e.preventDefault();openAdmin()});
$("comicForm").addEventListener("submit",async e=>{e.preventDefault();if(!isAdmin){info("Sem permissão","Só um administrador pode publicar.");return}const item={title:$("newTitle").value.trim(),category:$("newCategory").value,genre:$("newCategory").value.toUpperCase(),description:$("newDescription").value.trim(),cover:"ashes",chapters:[{title:$("newChapter").value.trim(),text:$("newChapterText").value.trim()}],createdAt:serverTimestamp()};try{const ref=await addDoc(collection(db,"comics"),item);comics.unshift({id:ref.id,...item,createdAt:new Date()});renderCatalog();renderAdminList();e.target.reset();info("História publicada","A história foi guardada na base de dados Firebase.")}catch(err){info("Não foi possível publicar",friendlyError(err))}});

$("premiumBtn").addEventListener("click",()=>{ $("paymentMessage").textContent="";showModal("premiumModal")});
const paymentCopy={visa:"Visa: será processado por um prestador de pagamentos compatível. O AnimeVerse nunca guarda o número completo do cartão.",paypal:"PayPal: será necessário configurar a conta comercial e a integração oficial de checkout.",usdt:"Bybit USDT: será necessário configurar a conta/merchant Bybit, rede suportada e confirmação automática da transação."};
$("paymentMethod").addEventListener("change",e=>$("paymentDetails").textContent=paymentCopy[e.target.value]);
$("paymentContinue").addEventListener("click",()=>{$("paymentMessage").textContent="Método selecionado. Checkout ainda não ativado: faltam as credenciais comerciais e o backend seguro. Não envies dinheiro para endereços não verificados."});

try{
 if(!firebaseConfig.apiKey||firebaseConfig.apiKey==="COLOCA_AQUI_A_API_KEY")throw new Error("Falta configurar o Firebase. Abre firebase-config.js e segue o guia CONFIGURAR-FIREBASE.txt.");
 app=initializeApp(firebaseConfig);auth=getAuth(app);db=getFirestore(app);
 onAuthStateChanged(auth,updateAccountUI);
}catch(e){console.error(e);$("userGreeting").textContent="Firebase por configurar";$("accountBtn").addEventListener("click",()=>info("Configuração necessária",e.message));}
renderCatalog();renderChapters();accountTab();
